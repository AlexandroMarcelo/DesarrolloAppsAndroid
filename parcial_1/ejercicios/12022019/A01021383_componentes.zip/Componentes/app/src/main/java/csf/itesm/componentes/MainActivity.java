package csf.itesm.componentes;

import android.graphics.drawable.VectorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void clickBtnGuardar(View view){
        DespliegaToast("Has dado click en el boton de guardar");
        //Toast.makeText(btnPulsame.getContext(), "Haz dado Click", Toast.LENGTH_LONG).show();//por si no quiero crear una funcion
    }
    public void clickBtnAbrir(View view){
        DespliegaToast("Has dado click en el boton de abrir");
    }
    public void clickBtnImage(View view){
        DespliegaToast("Has dado click en la imagen");
    }
    public void clickTextNombre(View view){
        EditText introducedText = (EditText)findViewById(R.id.txtNombre);
        String content = introducedText.getText().toString(); //gets you the contents of edit text
        if(!content.isEmpty()){
            DespliegaToast("Has introducido: " + content);
        }
    }
    public void clickCheckBtnAutoguardar(View view){
        DespliegaToast("Has dado click en Autoguardado");
    }
    public void clickCheckBox2(View view){
        DespliegaToast("Has dado click en Estrella");
    }

    public void clickBtnOff(View view){
        DespliegaToast("Has dado click en el boton OFF");
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnOpen = (Button) findViewById(R.id.btnGuardar);
        /*
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DespliegaToast("Has dado click en guardar");
            }
        });*/
    }
    private void DespliegaToast(String msg){
        Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
    }
}
